// This file is kept for backward compatibility
// States are now defined in their respective cubit files:
// - chat_list_state.dart
// - conversation_state.dart
