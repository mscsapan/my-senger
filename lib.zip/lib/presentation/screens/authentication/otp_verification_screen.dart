import 'package:flutter/material.dart';

class OtpVerificationScreen extends StatelessWidget {
  const OtpVerificationScreen({super.key, required this.isNew});
  final bool isNew;

  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
